pcvs.cli.cli\_config module
===========================

.. automodule:: pcvs.cli.cli_config
   :members:
   :undoc-members:
   :show-inheritance:
