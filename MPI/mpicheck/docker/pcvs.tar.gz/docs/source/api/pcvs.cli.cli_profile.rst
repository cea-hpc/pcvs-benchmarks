pcvs.cli.cli\_profile module
============================

.. automodule:: pcvs.cli.cli_profile
   :members:
   :undoc-members:
   :show-inheritance:
