pcvs.cli.cli\_report module
===========================

.. automodule:: pcvs.cli.cli_report
   :members:
   :undoc-members:
   :show-inheritance:
