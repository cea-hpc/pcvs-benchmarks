pcvs.helpers.criterion module
=============================

.. automodule:: pcvs.helpers.criterion
   :members:
   :undoc-members:
   :show-inheritance:
