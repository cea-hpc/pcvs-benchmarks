pcvs.testing.tedesc module
==========================

.. automodule:: pcvs.testing.tedesc
   :members:
   :undoc-members:
   :show-inheritance:
