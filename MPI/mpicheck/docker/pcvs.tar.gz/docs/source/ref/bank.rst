#################
 Bank management
#################

About
#####


Create/manage/delete a bank
###########################


Feed a bank with results
########################

