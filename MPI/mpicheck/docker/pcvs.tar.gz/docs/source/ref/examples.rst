##################
 Input Examples
##################

.. _te-format:

TE nodes: The complete list
###########################

.. literalinclude:: ../examples/te-format.yml
    :language: yaml
    :linenos:

Profile: The complete list
##########################

.. litaralinclude:: ../examples/
    :language: yaml
    :lineos: