##################
 Plugins
##################

About
#####

Possible passes
***************

* ``START_BEFORE``
* ``START_AFTER``
* ``TFILE_BEFORE``
* ``TDESC_BEFORE``
* ``TEST_EVAL``
* ``TDESC_AFTER``
* ``TFILE_AFTER``
* ``SCHED_BEFORE``
* ``SCHED_SET_BEFORE``
* ``SCHED_SET_EVAL``
* ``SCHED_SET_AFTER``
* ``SCHED_PUBLISH_BEFORE``
* ``SCHED_PUBLISH_AFTER``
* ``SCHED_AFTER``
* ``END_BEFORE``
* ``END_AFTER``

Create a new plugin
###################


Debug a plugin
##############

A special case: runtime Plugins
###############################

