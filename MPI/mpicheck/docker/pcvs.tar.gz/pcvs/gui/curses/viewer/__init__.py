from pcvs import io
from pcvs.gui.curses.viewer.model import TheModel
from pcvs.gui.curses.viewer.viewer import TheView


def start_job_viewer_app(p=None) -> int:
    app = TheView(TheModel(p)).run()
    return 0
        
