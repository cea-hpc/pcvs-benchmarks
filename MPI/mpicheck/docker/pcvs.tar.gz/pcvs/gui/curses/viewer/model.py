import shutil
import tarfile
import tempfile
import os
from typing import Optional

from pcvs import io, NAME_BUILD_RESDIR
from pcvs.backend import utilities
from pcvs.orchestration.publishers import BuildDirectoryManager


class TheModel:
    def __init__(self, p: Optional[str] = None) -> None:
        self._path: str = p
        self._decompressed_path = None
        self._config = None
        self._datatree = {}
    
    @property
    def current_path(self) -> str:
        return self._path
    
    def set_new_path(self, p) -> None:
        self._path = p
        
        if self._decompressed_path:
            shutil.rmtree(self._decompressed_path)
        
        self._decompressed_path = None
        self._config = None
        self._datatree = {}
    
    @property
    def labels(self):
        return self._datatree.keys()
    
    @property
    def datatree(self):
        return self._datatree
        
    
    def has_loaded_path(self) -> bool:
        return self._path is not None
    
    def validate_input_dataloading(self, p: str, update_if_valid=False) -> bool:
        if utilities.check_is_archive(p):
            if update_if_valid:
                self._path = p
            return True
        return False
    
    def do_load_data(self):
        def members(x):
            l = len("save_for_export/")
            for member in x.getmembers():
                if member.path.startswith("save_for_export/"):
                    member.path = member.path[l:]
                yield member
                
        self._decompressed_path = tempfile.mkdtemp(prefix="pcvs-viewer")
        tar = tarfile.open(self._path)
        tar.extractall(self._decompressed_path, members=members(tar))
        
        self._man = BuildDirectoryManager(os.path.join(self._decompressed_path))
        for test in self._man.results.browse_tests():
                io.console.debug(test.name)
                d = self._datatree
                for elt in test.name.split('/')[:-1]:
                    d.setdefault(elt, {})
                    d = d[elt]
                d[test.name.split('/')[-1]] = test
                    
        io.console.debug(self._datatree)
