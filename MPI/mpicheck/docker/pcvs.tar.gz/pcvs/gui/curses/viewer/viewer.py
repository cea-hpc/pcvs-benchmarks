#!/usr/bin/env python3
import os
from dataclasses import dataclass
from pathlib import Path

from rich.markdown import Markdown
from rich.spinner import Spinner
from textual.app import App
from textual.containers import Container, Grid
from textual.reactive import Reactive
from textual.screen import Screen
from textual.widgets import (Button, DirectoryTree, Footer, Header, Label,
                             Static, Tree)

from pcvs import io
from pcvs.gui.curses.viewer.model import TheModel

HELP_MD = """
# USAGE

```python
to be written
```
"""

class PleaseWait(Container):
    def compose(self):
        yield Label("Please Wait")
        
    

class BaseHeader(Header):
    def __init__(self):
        super().__init__(show_clock=True)

class BaseFooter(Footer):
    pass

class DataLoadingScreen(Screen):
    BINDINGS = [('q', 'pop_screen', 'Back')]
    last_select = None
    
    def compose(self):
        yield BaseHeader()
        yield Container(
            Static("Pick a valid PCVS archive below:"),
            Grid(
                DirectoryTree(os.path.expanduser('~'), id="filepicker"),
                Container(
                    Button(label="Select", variant="primary", id="select"),
                    Button(label="Cancel", variant="error", id="cancel")
                ),
                
                Label("", id="load_message"),
            )
        )
        yield BaseFooter()

    def on_button_pressed(self, event):
        if event.button.id == "select":
            path = DataLoadingScreen.last_select
            print(path)
            if path is None:
                return
            if not self.app.model.validate_input_dataloading(path, update_if_valid=True):
                self.query_one("#load_message", Label).update("[red bold]Not a PCVS archive![/]")
                return
            self.app.model.set_new_path(path)
            self.app.get_screen('main').refresh_content()
        self.app.pop_screen()

    def on_directory_tree_file_selected(self, event: DirectoryTree.FileSelected):
        event.stop()
        DataLoadingScreen.last_select = event.path


class HelpScreen(Screen):
    BINDINGS = [('q', 'app.pop_screen', 'Back')]
    def compose(self):
        yield Static(Markdown(HELP_MD))
    pass

class MainBodyScreen(Screen):
    def compose(self):
        self.jobs = Tree(label="Job List", id="jobs", classes="box")
        self.jobinfo = Static("Job Information", id="jobinfo", classes="box")
        self.out = Static("Output", id="jobout", classes="box")
        self.wait = PleaseWait(id="waitscreen")
        yield BaseHeader()
        yield Grid(self.jobs, self.jobinfo, self.out, id="main")
        yield self.wait
        yield BaseFooter()
        
    def on_mount(self):
        self.wait.add_class("hidden")
        self.refresh_content()
    
    def refresh_content(self) -> None:
        model = self.app.model
        if model.has_loaded_path():
            self.query_one("#waitscreen").remove_class("hidden")
            model.do_load_data()
            def build_subtree(parent, subtree):
                
                for k, v in subtree.items():
                    if isinstance(v, dict):
                        node = parent.add(k, allow_expand=True, expand=True)
                        build_subtree(node, v)
                    else:
                        parent.add(k, allow_expand=False)
                    
                    
            for k,v in model.datatree.items():
                node = self.jobs.root.add(k)
                build_subtree(node, v)
            self.query_one("#waitscreen").add_class("hidden")
        self.jobs.root.expand()

    def on_tree_node_selected(self, event: Tree.NodeSelected):
        event.stop()
        #if not isinstance(self.jobs.cursor_node, Node):
        #    return
        
        
class ExitConfirmScreen(Screen):
    def compose(self):
        yield Grid(
                Static("Are you sure you want to quit?", id="question"),
                Button("Quit", variant="error", id="quit"),
                Button("Cancel", variant="primary", id="cancel"),
                id="dialog",
                )

    def on_button_pressed(self, event):
        if event.button.id == "quit":
            self.app.exit()
        else:
            self.app.pop_screen()

class TheView(App):
    TITLE = "PCVS Job Result Viewer"
    SCREENS = {
            "main": MainBodyScreen(),
            "load": DataLoadingScreen(),
            "help": HelpScreen(),
            "exit": ExitConfirmScreen()
            }
    BINDINGS = [
            ('ctrl+t', 'toggle_dark', 'Theme'),
            ('h', 'app.push_screen("help")', 'Help'),
            ('o', 'load_data', 'Load'),
            ('ctrl+q', 'push_screen("exit")', 'Exit')
            ]
    CSS_PATH = "viewer.css" 
    
    archive_path = None   
        
    def __init__(self, model=None):
        super().__init__()
        self.model = model if model else TheModel()

    def on_mount(self):
        self.push_screen('main')

    def action_load_data(self):
        self.push_screen("load")